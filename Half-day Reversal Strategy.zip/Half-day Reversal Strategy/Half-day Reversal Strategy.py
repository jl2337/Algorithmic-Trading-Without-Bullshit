#!/usr/bin/env python
# coding: utf-8

# In[4]:


# 导包
import numpy as np
import pandas as pd
from math import *

# --------------------数据预处理 -----------------------

# 读取数据
'''
笔测规定使用 提供的EXCEL表格，故不使用wind量化接口
'''
hs300 = pd.read_excel('/Users/liujiajie/Desktop/HS300 DATA.xlsx',)
hs300.columns = np.arange(len(hs300.columns))

# 股票代码
stock_code = list(hs300.iloc[0].dropna())

# 交易日期
trade_date = list(hs300.iloc[:,0][4:].apply(lambda x: str(x)[:10]))[:-1]

'''
对开盘、收盘价格进行矩阵化处理
方便计算当日涨跌幅矩阵（用以选股）、次日开盘比当日收盘涨跌幅矩阵（用以计算策略收益）
'''

# 开盘价
open_price = hs300.loc[:,1::4]
open_price.columns = open_price.iloc[0]
open_price = open_price.drop(index=[0,1,2,3,487])
open_price.index = trade_date

# 收盘价
close_price = hs300.loc[:,2::4]
close_price.columns = stock_code
close_price = close_price.drop(index=[0,1,2,3,487])
close_price.index = trade_date

# 当日涨跌幅
daily_return = close_price/open_price -1

# 次日开盘价与当日收盘价的涨跌幅
reversal_return = open_price/close_price.shift(1) - 1


# ---------------------策略回测-----------------------
'''
---------------- Half-day Reversal Strategy ----------------

股票池：沪深300指数中所有成份股
选股策略：该策略买入最差的N股，剔除空值，N = 剩余股票数量 * 10%
               所以，每日仓位的持股数量不固定，不一定等于30
调仓时间：每日调仓，收盘价买入，次日开盘价卖出
组合权重：等权处理
交易成本：万分之七，此策略不考虑
不考虑：交易滑点，市场冲击成本

------------------------------------------------------
'''

# 设置参数类
'''
请在参数类中设置策略的参数
'''
class para:
    # 调仓比例
    adj_pct = 0.1
    # 交易成本
    #com_rate = 7/10000

# 选股
'''
输入参数为交易日期，输出结果为 选股策略所得出的股票列表
'''
def pick_stock(dt):
    temp = daily_return.loc[dt].sort_values().dropna()
    stock_list = list(temp[:floor(len(temp)*para.adj_pct)].index)
    return stock_list

# 策略收益的时序数据
def get_strat_return_TS():
    # 时序数据初始化
    strat_return = []; cum_return = [1]
    for i in range(len(trade_date)-1):
        # 当日选股
        strat_list = pick_stock(trade_date[i])
        # 次日收益
        ret = np.mean(list(reversal_return.loc[trade_date[i+1],strat_list]))
        strat_return.append(ret)
        cum_return.append(cum_return[-1]*(1+ret))
    del cum_return[0]
    df = pd.DataFrame({'策略单日收益':strat_return,'策略累计收益':cum_return},index=trade_date[1:])
    return df

# 显示回测结果
result = get_strat_return_TS()

# 初步报告
'''
简单评价一下该策略：
一、该策略的组合净值几乎是一条斜线向下走，回撤及其严重。
二、不过这也不是坏事，策略思路改改，反转策略改为趋势跟踪策略，理论上，收益会大为改观。
三、可惜的是，若调整为趋势跟踪策略，需要每天卖空策略选出的股票组合，
      次日开盘再买入，可是国内卖空股票是受到限制的，所以策略难以实盘实现。
四、回测没有将交易费用、交易滑点、市场冲击成本考虑入内
五、等权买入股票组合，基于资产的完美可分性，向下取整会更科学
六、可以在此选股策略基础上，加入组合优化、择时，使策略表现进一步改观
七、EXCEL不包含沪深300指数数据。
      除了策略收益，有时间可以再算算超额收益，夏普率，回撤率，胜率，风险等指标
      可以考虑使用pyfolio提供的API计算

'''
result
        
        
        
        
    



    

    

    
    

